CREATE PROCEDURE InsertClass(IN ClassName VARCHAR(20))
  BEGIN
INSERT INTO Class (ID,Name) VALUES ('',ClassName);
END;

